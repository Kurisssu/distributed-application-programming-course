﻿namespace Common
{
    public class Settings
    {
        public static int BROKER_PORT = 9000;
        public static string BROKER_IP = "127.0.0.1";
    }
}
